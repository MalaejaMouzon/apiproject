import requests

API_KEY = "13123a773574850adf91d79b02eea5c5"
CITY = "Palm Bay"
URL = f"http://api.openweathermap.org/data/2.5/weather?q={CITY}&appid={API_KEY}&units=metric"

response = requests.get(URL)

if response.status_code == 200:
    data = response.json()
    temperature = data["main"]["temp"]
    weather_desc = data["weather"][0]["description"]
    print(f"Current temperature in {CITY}: {temperature}°C, {weather_desc}")
else:
    print("Error fetching data from OpenWeatherMap.")
